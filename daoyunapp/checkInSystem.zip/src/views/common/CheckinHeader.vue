<template>
    <div>
        <mt-header title="签到Star">
            <router-link to="/" slot="left">
                <mt-button icon="back">返回</mt-button>
                <mt-button @click="handleClose">关闭</mt-button>
            </router-link>
            <mt-button icon="more" slot="right"></mt-button>
        </mt-header>
    </div>
</template>

<script>
    export default {
        name: "CheckinHeader",
    }
</script>

<style scoped>

</style>