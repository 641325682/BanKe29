<template>
    <div>发现</div>
</template>

<script>
    export default {
        name: "DiscoveryIndex"
    }
</script>

<style scoped>

</style>