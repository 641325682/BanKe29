<template>
    <div>课程表</div>
</template>

<script>
    export default {
        name: "ScheduleIndex"
    }
</script>

<style scoped>

</style>