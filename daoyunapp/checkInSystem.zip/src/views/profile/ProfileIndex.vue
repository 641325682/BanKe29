<template>
    <div>
    <checkin-header></checkin-header>
        我的
    </div>
</template>

<script>
    import CheckinHeader from '@/views/common/CheckinHeader.vue'

    export default {
        name: "ProfileIndex",
        components:{
            CheckinHeader
        }
    }
</script>

<style scoped>

</style>