module.exports = {
  publicPath: './',
  outputDir: '../www',

  // assetsDir: 'static',
};

